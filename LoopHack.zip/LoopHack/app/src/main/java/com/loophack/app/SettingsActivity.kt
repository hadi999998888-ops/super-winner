package com.loophack.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

class SettingsActivity : Activity() {

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BLACK)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(16), d(20), d(16), d(32))
        scroll.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Ui.text(this, "Настройки", 22f, Ui.WHITE, true), Ui.lin(0, Ui.WRAP, 1f))
        head.addView(Ui.chip(this, "Назад") { finish() })
        col.addView(head)

        // Сквозные касания
        col.addView(Ui.toggle(this, "Закреплённые элементы пропускают касания", Repo.passThrough(this)) {
            Repo.setPassThrough(this, it)
            OverlayService.refresh()
        }, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(18), 0, 0))
        col.addView(
            Ui.text(
                this,
                "Включено: закреплённый элемент неподвижен, а нажатия проходят сквозь него в TikTok. " +
                        "На Android 12+ такие элементы показываются максимум с 80% непрозрачности " +
                        "(правило системы). Выключено: элемент остаётся 100% непрозрачным, но перехватывает нажатия.",
                12f, Ui.GRAY
            )
        )

        // Логотип
        col.addView(Ui.toggle(this, "Рекламный логотип LOOP HACK на оверлее", Repo.hasLogo(this)) { on ->
            if (on) {
                if (!Repo.hasLogo(this)) Repo.addLogo(this)
            } else {
                Repo.removeLogos(this)
            }
            OverlayService.refresh()
        }, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(18), 0, 0))
        col.addView(
            Ui.text(this, "Логотип можно двигать, масштабировать и скрывать, как любой другой элемент.", 12f, Ui.GRAY)
        )

        // Размер новых медиа
        col.addView(
            Ui.seek(this, "Ширина новых фото и видео (dp)", 80, 600, Repo.mediaWidth(this), { "$it" }) {
                Repo.setMediaWidth(this, it)
            }, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(18), 0, 0)
        )
        col.addView(Ui.text(this, "Применяется к элементам, которые вы добавите после изменения.", 12f, Ui.GRAY))

        // Управление
        col.addView(
            Ui.button(this, "Остановить оверлеи", 1) {
                OverlayService.stop(this)
                Ui.toast(this, "Оверлеи остановлены")
            }, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(22), 0, 0)
        )
        col.addView(Links.telegramButton(this), Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(10), 0, 0))
        col.addView(
            Ui.text(this, "LOOP HACK Overlay Studio · версия 1.0", 12f, Ui.GRAY),
            Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(22), 0, 0)
        )

        setContentView(scroll)
    }
}
