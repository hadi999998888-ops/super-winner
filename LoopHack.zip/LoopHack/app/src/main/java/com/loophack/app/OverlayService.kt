package com.loophack.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager
import androidx.core.content.ContextCompat

/** Foreground-сервис: держит окна оверлеев, пока включён режим стрима. */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.loophack.app.action.STOP"
        private const val CHANNEL = "loophack_overlay"
        private const val NOTIF_ID = 1001

        @Volatile
        var instance: OverlayService? = null

        val running: Boolean get() = instance != null

        fun start(c: Context) {
            ContextCompat.startForegroundService(c, Intent(c, OverlayService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, OverlayService::class.java))
        }

        /** Перечитать элементы из хранилища и обновить окна (если сервис запущен). */
        fun refresh() {
            instance?.sync()
        }

        fun replay(id: String) {
            instance?.windows?.get(id)?.replay()
        }
    }

    private val windows = LinkedHashMap<String, OverlayWindow>()
    private val attachedOrder = ArrayList<String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startAsForeground()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        sync()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "LOOP HACK — оверлеи", NotificationManager.IMPORTANCE_LOW)
        )
        val pf = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), pf)
        val stopIntent = Intent(this, OverlayService::class.java).setAction(ACTION_STOP)
        val stop = PendingIntent.getService(this, 1, stopIntent, pf)
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_stat), "Остановить", stop
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("LOOP HACK")
            .setContentText("Оверлеи активны")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(action)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun persist(item: Item) {
        Repo.mutate(this, item.id) {
            it.cx = item.cx
            it.cy = item.cy
            it.scale = item.scale
            it.rotation = item.rotation
        }
    }

    fun sync() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val items = Repo.load(this)
        val pass = Repo.passThrough(this)
        val ids = items.map { it.id }.toSet()

        for (id in windows.keys.filter { it !in ids }) {
            windows.remove(id)?.destroy()
            attachedOrder.remove(id)
        }
        for (item in items) {
            val w = windows[item.id]
            if (w == null) {
                windows[item.id] = OverlayWindow(this, wm, item, pass) { persist(it) }
            } else {
                w.update(item, pass)
            }
        }

        // Порядок слоёв = порядок в списке (последний — самый верхний).
        val desired = items.filter { it.visible }.map { it.id }
        val needReorder = desired != attachedOrder || desired.any { windows[it]?.attached != true }
        if (needReorder) {
            for (id in attachedOrder.toList()) windows[id]?.detach()
            attachedOrder.clear()
            for (id in desired) windows[id]?.attach()
            attachedOrder.addAll(desired)
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val dm = resources.displayMetrics
        Repo.mutateAll(this) {
            it.cx = it.cx.coerceIn(0f, dm.widthPixels.toFloat())
            it.cy = it.cy.coerceIn(0f, dm.heightPixels.toFloat())
        }
        sync()
    }

    override fun onDestroy() {
        for (w in windows.values) w.destroy()
        windows.clear()
        attachedOrder.clear()
        instance = null
        super.onDestroy()
    }
}
