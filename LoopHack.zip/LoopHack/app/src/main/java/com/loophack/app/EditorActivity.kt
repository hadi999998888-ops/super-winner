package com.loophack.app

import android.app.Activity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView

/** Создание и редактирование текстового элемента с живым предпросмотром. */
class EditorActivity : Activity() {

    private lateinit var item: Item
    private var isNew = false
    private lateinit var preview: FrameLayout
    private lateinit var edit: EditText
    private lateinit var fontRow: LinearLayout

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        val existing = if (id != null) Repo.load(this).find { it.id == id } else null
        if (existing != null) {
            item = existing
        } else {
            isNew = true
            item = Item(id = Repo.newId(), type = Type.TEXT, text = "", glow = 10f)
        }
        build()
        refreshPreview()
    }

    private fun refreshPreview() {
        preview.removeAllViews()
        val tmp = item.copy(text = edit.text.toString().ifEmpty { "Ваш текст" })
        val v = ItemViews.makeText(this, tmp, 1f)
        v.alpha = item.alpha.coerceIn(0.05f, 1f)
        preview.addView(v, FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER))
    }

    private fun refreshFonts() {
        fontRow.removeAllViews()
        ItemViews.fontNames.forEachIndexed { i, name ->
            fontRow.addView(
                Ui.chip(this, name, item.font == i) {
                    item.font = i
                    refreshFonts()
                    refreshPreview()
                },
                Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, 0, d(8), 0)
            )
        }
    }

    private fun build() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BLACK)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.setPadding(d(16), d(14), d(16), d(6))
        top.addView(
            Ui.text(this, if (isNew) "Новый текст" else "Редактирование текста", 20f, Ui.WHITE, true),
            Ui.lin(0, Ui.WRAP, 1f)
        )
        root.addView(top)

        preview = FrameLayout(this)
        preview.background = Ui.rounded(0xFF2A2236.toInt(), d(16).toFloat(), 0x33FFFFFF, d(1))
        preview.clipChildren = true
        root.addView(preview, Ui.lin(Ui.MATCH, d(170), 0f, d(16), d(6), d(16), d(6)))

        val scroll = ScrollView(this)
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(d(16), d(4), d(16), d(16))
        scroll.addView(body, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, Ui.lin(Ui.MATCH, 0, 1f))

        fun heading(s: String) {
            body.addView(Ui.text(this, s, 12f, Ui.PINK, true), Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(16), 0, d(2)))
        }

        // Текст
        heading("ТЕКСТ")
        edit = EditText(this)
        edit.setText(item.text)
        edit.hint = "Введите текст"
        edit.setTextColor(Ui.WHITE)
        edit.setHintTextColor(Ui.GRAY)
        edit.minLines = 2
        edit.gravity = Gravity.TOP or Gravity.START
        edit.background = Ui.rounded(Ui.PANEL, d(12).toFloat(), 0x33B8A8C8, d(1))
        edit.setPadding(d(12), d(10), d(12), d(10))
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refreshPreview()
            }
        })
        body.addView(edit, Ui.lin(Ui.MATCH, Ui.WRAP))

        body.addView(
            Ui.seek(this, "Размер текста", 8, 120, item.textSize.toInt(), { "$it" }) {
                item.textSize = it.toFloat()
                refreshPreview()
            }
        )
        body.addView(Ui.colorRow(this, "Цвет текста", item.textColor) {
            item.textColor = it
            refreshPreview()
        })
        body.addView(Ui.toggle(this, "Жирный текст", item.bold) {
            item.bold = it
            refreshPreview()
        })
        body.addView(
            Ui.seek(this, "Прозрачность", 5, 100, (item.alpha * 100).toInt(), { "$it%" }) {
                item.alpha = it / 100f
                refreshPreview()
            }
        )

        // Шрифт
        heading("ШРИФТ")
        val fs = HorizontalScrollView(this)
        fs.isHorizontalScrollBarEnabled = false
        fontRow = LinearLayout(this)
        fontRow.orientation = LinearLayout.HORIZONTAL
        fs.addView(fontRow)
        body.addView(fs, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(4), 0, 0))
        refreshFonts()

        // Фон
        heading("ФОН ТЕКСТА")
        body.addView(Ui.toggle(this, "Цветной фон", item.bgEnabled) {
            item.bgEnabled = it
            refreshPreview()
        })
        body.addView(Ui.colorRow(this, "Цвет фона", item.bgColor) {
            item.bgColor = it
            refreshPreview()
        })
        body.addView(
            Ui.seek(this, "Ширина фона (отступ по бокам)", 0, 80, item.padH.toInt(), { "$it" }) {
                item.padH = it.toFloat()
                refreshPreview()
            }
        )
        body.addView(
            Ui.seek(this, "Высота фона (отступ сверху/снизу)", 0, 60, item.padV.toInt(), { "$it" }) {
                item.padV = it.toFloat()
                refreshPreview()
            }
        )

        // Обводка
        heading("ОБВОДКА")
        body.addView(
            Ui.seek(this, "Толщина обводки", 0, 12, item.strokeWidth.toInt(), { "$it" }) {
                item.strokeWidth = it.toFloat()
                refreshPreview()
            }
        )
        body.addView(Ui.colorRow(this, "Цвет обводки", item.strokeColor) {
            item.strokeColor = it
            refreshPreview()
        })

        // Свечение
        heading("СВЕЧЕНИЕ")
        body.addView(
            Ui.seek(this, "Сила свечения", 0, 40, item.glow.toInt(), { "$it" }) {
                item.glow = it.toFloat()
                refreshPreview()
            }
        )
        body.addView(Ui.colorRow(this, "Цвет свечения", item.glowColor) {
            item.glowColor = it
            refreshPreview()
        })

        // Нижние кнопки
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.setPadding(d(16), d(8), d(16), d(14))
        bar.addView(Ui.button(this, "Отмена", 1) { finish() }, Ui.lin(0, Ui.WRAP, 1f, 0, 0, d(8), 0))
        bar.addView(Ui.button(this, if (isNew) "Добавить" else "Сохранить", 0) { save() }, Ui.lin(0, Ui.WRAP, 2f))
        root.addView(bar)

        setContentView(root)
    }

    private fun save() {
        val t = edit.text.toString()
        if (t.isBlank()) {
            Ui.toast(this, "Введите текст")
            return
        }
        item.text = t
        if (isNew) {
            Repo.place(this, item)
            Repo.add(this, item)
        } else {
            val src = item
            Repo.mutate(this, src.id) { it.copyStyleFrom(src) }
        }
        OverlayService.refresh()
        finish()
    }
}
