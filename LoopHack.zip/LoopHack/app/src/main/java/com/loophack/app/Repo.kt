package com.loophack.app

import android.content.Context
import org.json.JSONArray
import java.util.UUID

/** Хранилище элементов и настроек (SharedPreferences, JSON). Всё вызывается из главного потока. */
object Repo {
    private const val PREFS = "loophack"
    private const val KEY_ITEMS = "items"
    private const val KEY_SEEDED = "seeded"
    private const val KEY_MEDIA_W = "mediaWidth"

    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun newId(): String = UUID.randomUUID().toString()

    fun load(c: Context): MutableList<Item> {
        val s = sp(c).getString(KEY_ITEMS, null) ?: return mutableListOf()
        return try {
            val a = JSONArray(s)
            MutableList(a.length()) { Item.fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun save(c: Context, list: List<Item>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        sp(c).edit().putString(KEY_ITEMS, a.toString()).apply()
    }

    fun add(c: Context, item: Item) {
        val l = load(c)
        l.add(item)
        save(c, l)
    }

    fun remove(c: Context, id: String) {
        val l = load(c)
        l.removeAll { it.id == id }
        save(c, l)
    }

    fun clear(c: Context) = save(c, emptyList())

    fun mutate(c: Context, id: String, block: (Item) -> Unit) {
        val l = load(c)
        val item = l.find { it.id == id } ?: return
        block(item)
        save(c, l)
    }

    fun mutateAll(c: Context, block: (Item) -> Unit) {
        val l = load(c)
        l.forEach(block)
        save(c, l)
    }

    /** delta = +1 — выше слоем (ближе к зрителю), -1 — ниже. */
    fun move(c: Context, id: String, delta: Int) {
        val l = load(c)
        val i = l.indexOfFirst { it.id == id }
        val j = i + delta
        if (i < 0 || j < 0 || j >= l.size) return
        val t = l[i]
        l[i] = l[j]
        l[j] = t
        save(c, l)
    }

    fun hasLogo(c: Context): Boolean = load(c).any { it.type == Type.LOGO }

    fun addLogo(c: Context) {
        val dm = c.resources.displayMetrics
        add(
            c,
            Item(
                id = newId(),
                type = Type.LOGO,
                name = "LOOP HACK",
                baseWidth = 110f,
                cx = dm.widthPixels - 80f * dm.density,
                cy = 150f * dm.density
            )
        )
    }

    /** При самом первом запуске добавляет рекламный логотип (его можно скрыть/удалить). */
    fun ensureLogo(c: Context) {
        val p = sp(c)
        if (p.getBoolean(KEY_SEEDED, false)) return
        addLogo(c)
        p.edit().putBoolean(KEY_SEEDED, true).apply()
    }

    fun removeLogos(c: Context) {
        val l = load(c)
        l.removeAll { it.type == Type.LOGO }
        save(c, l)
    }

    fun passThrough(c: Context): Boolean = sp(c).getBoolean("passThrough", true)

    fun setPassThrough(c: Context, v: Boolean) {
        sp(c).edit().putBoolean("passThrough", v).apply()
    }

    /** Ставит новый элемент в видимую область со смещением, чтобы элементы не слипались. */
    fun place(c: Context, item: Item) {
        val dm = c.resources.displayMetrics
        val n = load(c).size % 6
        item.cx = dm.widthPixels / 2f + (n - 3) * 24f * dm.density
        item.cy = dm.heightPixels / 3f + n * 28f * dm.density
    }

    fun mediaWidth(c: Context): Int = sp(c).getInt(KEY_MEDIA_W, 200)

    fun setMediaWidth(c: Context, v: Int) {
        sp(c).edit().putInt(KEY_MEDIA_W, v).apply()
    }
}
