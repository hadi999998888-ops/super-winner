package com.loophack.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Outline
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    companion object {
        const val REQ_IMAGE = 1
        const val REQ_VIDEO = 2
        const val REQ_NOTIF = 4
    }

    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var btnLock: TextView
    private var pendingStart = false

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.ensureLogo(this)
        buildUi()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    override fun onResume() {
        super.onResume()
        if (pendingStart) {
            pendingStart = false
            if (Settings.canDrawOverlays(this)) launchService()
            else Ui.toast(this, "Разрешение не выдано — оверлеи не запущены")
        }
        updateAll()
    }

    // ------------------------------------------------------------------ интерфейс

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        v.forEachIndexed { i, x ->
            r.addView(x, Ui.lin(0, Ui.WRAP, 1f, if (i == 0) 0 else d(8), 0, 0, 0))
        }
        return r
    }

    private fun LinearLayout.put(v: View, top: Int = 10) {
        addView(v, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(top), 0, 0))
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BLACK)
        scroll.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(16), d(20), d(16), d(32))
        scroll.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Шапка с логотипом
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.CENTER_CROP
        logo.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, d(22).toFloat())
            }
        }
        logo.clipToOutline = true
        head.addView(logo, Ui.lin(d(96), d(96), 0f, 0, 0, d(16), 0))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = Ui.text(this, "LOOP HACK", 28f, Ui.WHITE, true)
        title.setShadowLayer(d(10).toFloat(), 0f, 0f, Ui.PINK)
        titles.addView(title)
        titles.addView(Ui.text(this, "Overlay Studio для TikTok-стримов", 13f, Ui.GRAY))
        head.addView(titles, Ui.lin(0, Ui.WRAP, 1f))
        col.addView(head)

        // Статус
        status = Ui.text(this, "", 13f, Ui.WHITE)
        status.background = Ui.rounded(Ui.PANEL, d(14).toFloat(), 0x33B8A8C8, d(1))
        status.setPadding(d(14), d(12), d(14), d(12))
        col.put(status, 16)

        // Главная кнопка
        col.put(Ui.button(this, "▶  ЗАПУСТИТЬ ОВЕРЛЕИ", 0) { startOverlays() }, 14)
        col.put(
            row(
                Ui.button(this, "Скрыть оверлеи", 1) {
                    OverlayService.stop(this)
                    Ui.toast(this, "Оверлеи скрыты")
                    status.postDelayed({ updateAll() }, 400)
                },
                Ui.button(this, "Настройки", 1) { startActivity(Intent(this, SettingsActivity::class.java)) }
            )
        )

        // Добавление
        col.addView(Ui.text(this, "ДОБАВИТЬ", 12f, Ui.PINK, true), Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(22), 0, 0))
        col.put(
            row(
                Ui.button(this, "Aa  Текст", 0) { startActivity(Intent(this, EditorActivity::class.java)) },
                Ui.button(this, "Фото", 0) { pick(REQ_IMAGE, "image/*", true) },
                Ui.button(this, "Видео", 0) { pick(REQ_VIDEO, "video/*", true) }
            ), 8
        )

        // Массовые действия
        btnLock = Ui.button(this, "Закрепить всё", 1) { toggleLockAll() }
        col.put(
            row(
                btnLock,
                Ui.button(this, "Удалить всё", 2) { confirmDeleteAll() }
            ), 10
        )

        col.put(Links.telegramButton(this), 14)

        // Список элементов
        col.addView(Ui.text(this, "ЭЛЕМЕНТЫ НА ЭКРАНЕ", 12f, Ui.PINK, true), Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(24), 0, 0))
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.put(list, 8)

        setContentView(scroll)
    }

    private fun updateAll() {
        val perm = Settings.canDrawOverlays(this)
        val on = OverlayService.running
        status.text = "Оверлеи: " + (if (on) "ВКЛЮЧЕНЫ" else "выключены") +
                "\nРазрешение «Поверх других приложений»: " + (if (perm) "выдано" else "не выдано")
        val items = Repo.load(this)
        btnLock.text = if (items.isNotEmpty() && items.all { it.locked }) "Открепить всё" else "Закрепить всё"
        rebuildList(items)
    }

    private fun rebuildList(items: List<Item> = Repo.load(this)) {
        list.removeAllViews()
        if (items.isEmpty()) {
            list.addView(Ui.text(this, "Пока пусто. Добавьте текст, фото или видео.", 14f, Ui.GRAY))
            return
        }
        // Сверху списка — самый верхний слой.
        for (item in items.reversed()) {
            list.addView(itemCard(item), Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, d(10)))
        }
    }

    private fun act(id: String, block: (Item) -> Unit) {
        Repo.mutate(this, id, block)
        OverlayService.refresh()
        updateAll()
    }

    private fun itemCard(item: Item): View {
        val id = item.id
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = Ui.rounded(Ui.PANEL, d(16).toFloat(), 0x33FF2DAA, d(1))
        card.setPadding(d(14), d(12), d(14), d(12))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val icon = when (item.type) {
            Type.TEXT -> "Aa"
            Type.IMAGE -> "🖼"
            Type.VIDEO -> "🎬"
            else -> "◆"
        }
        head.addView(Ui.text(this, icon, 18f, Ui.WHITE, true), Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, 0, d(10), 0))
        val title = Ui.text(this, item.title(), 15f, Ui.WHITE, true)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        head.addView(title, Ui.lin(0, Ui.WRAP, 1f))
        val state = when {
            !item.visible -> "скрыт"
            item.locked -> "закреплён"
            else -> "активен"
        }
        head.addView(Ui.text(this, state, 11f, if (item.visible) Ui.PINK else Ui.GRAY, true))
        card.addView(head)

        card.addView(
            Ui.seek(this, "Прозрачность", 5, 100, (item.alpha * 100).toInt(), { "$it%" }) { v ->
                Repo.mutate(this, id) { x -> x.alpha = v / 100f }
                OverlayService.refresh()
            }
        )
        card.addView(
            Ui.seek(this, "Размер", 10, 400, (item.scale * 100).toInt(), { "$it%" }) { v ->
                Repo.mutate(this, id) { x -> x.scale = v / 100f }
                OverlayService.refresh()
            }
        )

        val chips1 = row(
            Ui.chip(this, if (item.visible) "Скрыть" else "Показать", !item.visible) {
                act(id) { it.visible = !it.visible }
            },
            Ui.chip(this, if (item.locked) "Открепить" else "Закрепить", item.locked) {
                act(id) { it.locked = !it.locked }
            },
            Ui.chip(this, "Удалить") {
                Repo.remove(this, id)
                OverlayService.refresh()
                updateAll()
            }
        )
        card.put(chips1, 8)

        val moveRow = mutableListOf<View>(
            Ui.chip(this, "▲ Выше") {
                Repo.move(this, id, +1)
                OverlayService.refresh()
                updateAll()
            },
            Ui.chip(this, "▼ Ниже") {
                Repo.move(this, id, -1)
                OverlayService.refresh()
                updateAll()
            }
        )
        if (item.type == Type.TEXT) {
            moveRow.add(Ui.chip(this, "Изменить") {
                startActivity(Intent(this, EditorActivity::class.java).putExtra("id", id))
            })
        }
        card.put(row(*moveRow.toTypedArray()), 8)

        if (item.type == Type.VIDEO) {
            card.put(
                row(
                    Ui.chip(this, if (item.playing) "⏸ Пауза" else "▶ Играть", !item.playing) {
                        act(id) { it.playing = !it.playing }
                    },
                    Ui.chip(this, if (item.loop) "🔁 Повтор: вкл" else "🔁 Повтор: выкл", item.loop) {
                        act(id) { it.loop = !it.loop }
                    }
                ), 8
            )
            card.put(
                row(
                    Ui.chip(this, "↺ Сначала") {
                        act(id) { it.playing = true }
                        OverlayService.replay(id)
                    },
                    Ui.chip(this, if (item.muted) "🔇 Звук выкл" else "🔊 Звук вкл", !item.muted) {
                        act(id) { it.muted = !it.muted }
                    }
                ), 8
            )
        }
        return card
    }

    // ------------------------------------------------------------------ действия

    private fun toggleLockAll() {
        val items = Repo.load(this)
        if (items.isEmpty()) {
            Ui.toast(this, "Нет элементов")
            return
        }
        val all = items.all { it.locked }
        Repo.mutateAll(this) { it.locked = !all }
        OverlayService.refresh()
        updateAll()
        Ui.toast(this, if (all) "Все элементы откреплены" else "Все элементы закреплены")
    }

    private fun confirmDeleteAll() {
        if (Repo.load(this).isEmpty()) {
            Ui.toast(this, "Нечего удалять")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Удалить всё?")
            .setMessage("Все элементы оверлея будут удалены без возможности восстановления.")
            .setPositiveButton("Удалить") { _, _ ->
                Repo.clear(this)
                OverlayService.refresh()
                updateAll()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun startOverlays() {
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Нужно разрешение")
                .setMessage(
                    "Чтобы показывать элементы поверх TikTok, включите для LOOP HACK " +
                            "переключатель «Поверх других приложений», затем вернитесь назад."
                )
                .setPositiveButton("Открыть настройки") { _, _ ->
                    pendingStart = true
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                }
                .setNegativeButton("Отмена", null)
                .show()
            return
        }
        launchService()
    }

    private fun launchService() {
        try {
            OverlayService.start(this)
            Ui.toast(this, "Оверлеи запущены. Откройте TikTok")
        } catch (e: Exception) {
            Ui.toast(this, "Не удалось запустить сервис")
        }
        status.postDelayed({ updateAll() }, 500)
    }

    private fun pick(req: Int, mime: String, multi: Boolean) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multi)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, req)
        } catch (e: Exception) {
            Ui.toast(this, "Не удалось открыть галерею")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        if (requestCode != REQ_IMAGE && requestCode != REQ_VIDEO) return

        val uris = mutableListOf<Uri>()
        data.data?.let { uris.add(it) }
        val cd = data.clipData
        if (cd != null) {
            for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
        }
        val type = if (requestCode == REQ_IMAGE) Type.IMAGE else Type.VIDEO
        for (u in uris.distinct()) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // Не все провайдеры поддерживают постоянный доступ.
            }
            val item = Item(
                id = Repo.newId(),
                type = type,
                uri = u.toString(),
                name = displayName(u),
                baseWidth = Repo.mediaWidth(this).toFloat()
            )
            Repo.place(this, item)
            Repo.add(this, item)
        }
        OverlayService.refresh()
        updateAll()
        Ui.toast(this, "Добавлено: ${uris.distinct().size}")
    }

    private fun displayName(u: Uri): String {
        return try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) ?: "" else ""
            } ?: ""
        } catch (e: Exception) {
            ""
        }
    }
}
