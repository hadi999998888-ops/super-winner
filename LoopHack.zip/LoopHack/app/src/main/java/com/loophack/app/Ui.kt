package com.loophack.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Небольшой набор помощников для построения интерфейса из кода. */
object Ui {
    val BLACK = 0xFF0A0710.toInt()
    val PANEL = 0xFF1A1124.toInt()
    val PANEL2 = 0xFF261833.toInt()
    val VIOLET = 0xFF8A2BE2.toInt()
    val PINK = 0xFFFF2DAA.toInt()
    val WHITE = 0xFFFFFFFF.toInt()
    val GRAY = 0xFFB8A8C8.toInt()
    val DANGER = 0xFFB3174D.toInt()

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    val palette = intArrayOf(
        0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 0xFFFF2DAA.toInt(), 0xFF8A2BE2.toInt(),
        0xFF00E5FF.toInt(), 0xFF39FF14.toInt(), 0xFFFFE600.toInt(), 0xFFFF7A00.toInt(),
        0xFFFF1744.toInt(), 0xFF2979FF.toInt(), 0xFFFF00E5.toInt(), 0xFF9E9E9E.toInt()
    )

    fun dp(c: Context, v: Float): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()
    fun dp(c: Context, v: Int): Int = dp(c, v.toFloat())

    fun lin(w: Int, h: Int, weight: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(l, t, r, b) }

    fun rounded(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (strokeW > 0) setStroke(strokeW, strokeColor)
        }

    fun gradient(radius: Float): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(VIOLET, PINK)).apply {
            cornerRadius = radius
        }

    private fun ripple(bg: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, null)

    fun text(c: Context, s: String, size: Float = 14f, color: Int = WHITE, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    /** style: 0 — градиентная основная, 1 — вторичная, 2 — опасная. */
    fun button(c: Context, label: String, style: Int = 0, onClick: () -> Unit): TextView {
        val t = text(c, label, 14f, WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(c, 12), dp(c, 13), dp(c, 12), dp(c, 13))
        val r = dp(c, 14).toFloat()
        val bg: Drawable = when (style) {
            0 -> gradient(r)
            1 -> rounded(PANEL2, r, 0x55B8A8C8, dp(c, 1))
            else -> rounded(DANGER, r)
        }
        t.background = ripple(bg)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    fun chip(c: Context, label: String, active: Boolean = false, onClick: () -> Unit): TextView {
        val t = text(c, label, 12f, WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(c, 10), dp(c, 8), dp(c, 10), dp(c, 8))
        val r = dp(c, 10).toFloat()
        val bg: Drawable = if (active) gradient(r) else rounded(PANEL2, r, 0x33B8A8C8, dp(c, 1))
        t.background = ripple(bg)
        t.isClickable = true
        t.setOnClickListener { onClick() }
        return t
    }

    fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()

    fun seek(
        c: Context,
        title: String,
        lo: Int,
        hi: Int,
        value: Int,
        fmt: (Int) -> String = { it.toString() },
        onChange: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(c, 4), 0, dp(c, 4))
        }
        val label = text(c, "$title: ${fmt(value)}", 13f, GRAY)
        val bar = SeekBar(c)
        bar.max = hi - lo
        bar.progress = (value - lo).coerceIn(0, hi - lo)
        bar.progressTintList = ColorStateList.valueOf(PINK)
        bar.thumbTintList = ColorStateList.valueOf(PINK)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                label.text = "$title: ${fmt(v)}"
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(label)
        box.addView(bar, lin(MATCH, WRAP))
        return box
    }

    fun toggle(c: Context, title: String, checked: Boolean, onChange: (Boolean) -> Unit): Switch =
        Switch(c).apply {
            text = title
            setTextColor(WHITE)
            isChecked = checked
            setPadding(0, dp(c, 8), 0, dp(c, 8))
            setOnCheckedChangeListener { _, b -> onChange(b) }
        }

    /** Строка выбора цвета: палитра + ввод HEX. */
    fun colorRow(a: Activity, title: String, current: Int, onPick: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(a, 6), 0, dp(a, 6))
        }
        box.addView(text(a, title, 13f, GRAY))
        val scroll = HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        scroll.addView(row)
        box.addView(scroll, lin(MATCH, WRAP, 0f, 0, dp(a, 6), 0, 0))
        var cur = current

        fun fill() {
            row.removeAllViews()
            for (col in palette) {
                val sel = col == cur
                val v = View(a)
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(col)
                    setStroke(if (sel) dp(a, 3) else dp(a, 1), if (sel) WHITE else 0x66FFFFFF)
                }
                v.setOnClickListener {
                    cur = col
                    onPick(col)
                    fill()
                }
                row.addView(v, lin(dp(a, 34), dp(a, 34), 0f, 0, 0, dp(a, 10), 0))
            }
            val hex = chip(a, "HEX", false) {
                val input = EditText(a).apply {
                    hint = "FF2DAA"
                    setSingleLine(true)
                    setPadding(dp(a, 20), dp(a, 14), dp(a, 20), dp(a, 14))
                }
                AlertDialog.Builder(a)
                    .setTitle("Цвет в формате HEX")
                    .setView(input)
                    .setPositiveButton("OK") { _, _ ->
                        try {
                            val raw = input.text.toString().trim().removePrefix("#")
                            val col = Color.parseColor("#$raw")
                            cur = col
                            onPick(col)
                            fill()
                        } catch (e: Exception) {
                            toast(a, "Неверный цвет. Пример: FF2DAA")
                        }
                    }
                    .setNegativeButton("Отмена", null)
                    .show()
            }
            row.addView(hex, lin(WRAP, dp(a, 34)))
        }
        fill()
        return box
    }
}
