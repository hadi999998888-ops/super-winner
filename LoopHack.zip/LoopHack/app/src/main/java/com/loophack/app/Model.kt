package com.loophack.app

import org.json.JSONObject

object Type {
    const val TEXT = "text"
    const val IMAGE = "image"
    const val VIDEO = "video"
    const val LOGO = "logo"
}

/** Один элемент оверлея. cx/cy — центр элемента в пикселях экрана (-1 = ещё не размещён). */
data class Item(
    val id: String,
    val type: String,
    var text: String = "LOOP HACK",
    var textSize: Float = 32f,
    var textColor: Int = 0xFFFFFFFF.toInt(),
    var bold: Boolean = true,
    var font: Int = 0,
    var bgEnabled: Boolean = false,
    var bgColor: Int = 0xFF8A2BE2.toInt(),
    var padH: Float = 14f,
    var padV: Float = 6f,
    var strokeWidth: Float = 0f,
    var strokeColor: Int = 0xFF000000.toInt(),
    var glow: Float = 0f,
    var glowColor: Int = 0xFFFF2DAA.toInt(),
    var alpha: Float = 1f,
    var uri: String = "",
    var name: String = "",
    var cx: Float = -1f,
    var cy: Float = -1f,
    var scale: Float = 1f,
    var rotation: Float = 0f,
    var locked: Boolean = false,
    var visible: Boolean = true,
    var playing: Boolean = true,
    var loop: Boolean = true,
    var muted: Boolean = true,
    var baseWidth: Float = 200f
) {
    fun title(): String = when (type) {
        Type.TEXT -> text.replace("\n", " ").take(40)
        Type.LOGO -> "Логотип LOOP HACK"
        Type.IMAGE -> "Фото: " + name.ifEmpty { "без названия" }
        else -> "Видео: " + name.ifEmpty { "без названия" }
    }

    fun copyStyleFrom(o: Item) {
        text = o.text; textSize = o.textSize; textColor = o.textColor
        bold = o.bold; font = o.font
        bgEnabled = o.bgEnabled; bgColor = o.bgColor; padH = o.padH; padV = o.padV
        strokeWidth = o.strokeWidth; strokeColor = o.strokeColor
        glow = o.glow; glowColor = o.glowColor
        alpha = o.alpha
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type)
        put("text", text)
        put("textSize", textSize.toDouble())
        put("textColor", textColor)
        put("bold", bold)
        put("font", font)
        put("bgEnabled", bgEnabled)
        put("bgColor", bgColor)
        put("padH", padH.toDouble())
        put("padV", padV.toDouble())
        put("strokeWidth", strokeWidth.toDouble())
        put("strokeColor", strokeColor)
        put("glow", glow.toDouble())
        put("glowColor", glowColor)
        put("alpha", alpha.toDouble())
        put("uri", uri)
        put("name", name)
        put("cx", cx.toDouble())
        put("cy", cy.toDouble())
        put("scale", scale.toDouble())
        put("rotation", rotation.toDouble())
        put("locked", locked)
        put("visible", visible)
        put("playing", playing)
        put("loop", loop)
        put("muted", muted)
        put("baseWidth", baseWidth.toDouble())
    }

    companion object {
        fun fromJson(o: JSONObject): Item {
            val d = Item("", Type.TEXT)
            return Item(
                id = o.getString("id"),
                type = o.optString("type", Type.TEXT),
                text = o.optString("text", d.text),
                textSize = o.optDouble("textSize", d.textSize.toDouble()).toFloat(),
                textColor = o.optInt("textColor", d.textColor),
                bold = o.optBoolean("bold", d.bold),
                font = o.optInt("font", d.font),
                bgEnabled = o.optBoolean("bgEnabled", d.bgEnabled),
                bgColor = o.optInt("bgColor", d.bgColor),
                padH = o.optDouble("padH", d.padH.toDouble()).toFloat(),
                padV = o.optDouble("padV", d.padV.toDouble()).toFloat(),
                strokeWidth = o.optDouble("strokeWidth", d.strokeWidth.toDouble()).toFloat(),
                strokeColor = o.optInt("strokeColor", d.strokeColor),
                glow = o.optDouble("glow", d.glow.toDouble()).toFloat(),
                glowColor = o.optInt("glowColor", d.glowColor),
                alpha = o.optDouble("alpha", d.alpha.toDouble()).toFloat(),
                uri = o.optString("uri", ""),
                name = o.optString("name", ""),
                cx = o.optDouble("cx", -1.0).toFloat(),
                cy = o.optDouble("cy", -1.0).toFloat(),
                scale = o.optDouble("scale", 1.0).toFloat(),
                rotation = o.optDouble("rotation", 0.0).toFloat(),
                locked = o.optBoolean("locked", false),
                visible = o.optBoolean("visible", true),
                playing = o.optBoolean("playing", true),
                loop = o.optBoolean("loop", true),
                muted = o.optBoolean("muted", true),
                baseWidth = o.optDouble("baseWidth", d.baseWidth.toDouble()).toFloat()
            )
        }
    }
}
