package com.loophack.app

import android.content.Context
import android.content.Intent
import android.net.Uri

object Links {
    const val TELEGRAM = "https://t.me/ExtraCheatStanddof2"

    /** Просто открывает ссылку: Telegram, если установлен, иначе браузер. */
    fun openTelegram(c: Context) {
        try {
            c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Ui.toast(c, "Не удалось открыть ссылку")
        }
    }

    fun telegramButton(c: Context) = Ui.button(c, "✈  НАШ TELEGRAM-КАНАЛ", 0) { openTelegram(c) }
}
